import React, { createContext, useState, useEffect } from "react";

export const DashboardContext = createContext();

export const DashboardProvider = ({ children }) => {
  const [driveData, setDriveData] = useState(null);
  const [driveDashboardData, setDriveDashboardData] = useState(null);
  const [loading, setLoading] = useState(true);

  // let token = localStorage.getItem("token");
  let token = null;
  console.log("Outside useeffect", token);

  useEffect(() => {
    const fetchData = async () => {
      console.log("Inside useeffect", token);
      if (!token) {
        token = localStorage.getItem("token");
      }
      if (token) {
        try {
          const analyzeResponse = await fetch(
            `${process.env.REACT_APP_BACKEND_URL}/api/report/analyze`,
            {
              method: "GET",
              headers: { Authorization: `Bearer ${token}` },
              credentials: "include",
            }
          );

          const analyzeData = await analyzeResponse.json();

          const statsResponse = await fetch(
            ` ${process.env.REACT_APP_BACKEND_URL}/api/dashboard/stats   `,
            {
              method: "GET",
              headers: { Authorization: ` Bearer ${token}` },
              credentials: "include",
            }
          );

          const statsData = await statsResponse.json();

          setDriveData(analyzeData);
          setDriveDashboardData(statsData);
        } catch (error) {
          console.error("Error fetching dashboard data:", error);
        } finally {
          setLoading(false);
        }
      }
    };

    if (!driveData || !driveDashboardData) {
      fetchData();
    } else {
      setLoading(false);
    }
  }, [token, driveDashboardData, driveData]);

  return (
    <DashboardContext.Provider
      value={{ driveData, driveDashboardData, loading }}
    >
      {children}
    </DashboardContext.Provider>
  );
};
