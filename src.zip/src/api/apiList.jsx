//piechart api
export const fetchFileAgeDistribution = async () => {
  try {
    const response = await fetch(
      `${process.env.REACT_APP_BACKEND_URL}/api/charts/file-age-distribution`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        credentials: "include",
      }
    );
    if (response.status === 401) {
      console.warn("Unauthorized access. Redirecting to login...");
      localStorage.removeItem("token"); // Clear token
      window.location.href = "/"; // Redirect to login
      return { level: "Unauthorized", value: 0 };
    }

    if (response.status === 500) {
      console.error("Server error occurred.");
      return { level: "Error", value: 30 };
    }

    if (!response.ok) {
      throw new Error(`Unexpected error: ${response.status}`);
    }
    const data = await response.json();

    return data.map((item) => ({
      name: item.age_range,
      value: Number(item.count) || 0,
    }));
  } catch (error) {
    console.error("Error fetching risk data:", error);
    return [];
  }
};

//reanalyze button
export const reanalyzeReport = async () => {
  try {
    const response = await fetch(
      `${process.env.REACT_APP_BACKEND_URL}/api/report/analyze?analyzeAgain=true`,
      {
        method: "GET",
        headers: {
          Authorization: `Bearer ${localStorage.getItem("token")}`,
        },
        credentials: "include",
      }
    );

    if (!response.ok) {
      throw new Error("Failed to reanalyze report");
    }

    return await response.json();
  } catch (error) {
    console.error("Error reanalyzing report:", error);
    return { success: false, error: error.message };
  }
};
