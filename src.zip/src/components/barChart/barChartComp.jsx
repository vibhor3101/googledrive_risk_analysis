import React, { useEffect, useState, useRef } from "react";
import { Paper, Box, Typography, IconButton, Popover } from "@mui/material";
import InfoIcon from "@mui/icons-material/Info";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from "recharts";

const COLORS = {
  High: "#F44336", // Red
  Medium: "#FF9800", // Orange
  Low: "#4CAF50", // Green
};

const BarChartComp = () => {
  const [data, setData] = useState([]);
  const [anchorEl, setAnchorEl] = useState(null);
  const popoverTimeout = useRef(null);

  useEffect(() => {
    const fetchRiskData = async () => {
      try {
        const response = await fetch(
          `${process.env.REACT_APP_BACKEND_URL}/api/charts/risk-level-distribution`,
          {
            method: "GET",
            headers: {
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
            credentials: "include",
          }
        );

        if (response.status === 401) {
          console.warn("Unauthorized access. Redirecting to login...");
          localStorage.removeItem("token");
          window.location.href = "/";
          return;
        }

        if (response.status === 500) {
          console.error("Server error occurred.");
          return;
        }

        if (!response.ok) {
          throw new Error(`Unexpected error: ${response.status}`);
        }

        const apiData = await response.json();
        setData(apiData);
      } catch (error) {
        console.error("Error fetching risk data:", error);
      }
    };

    fetchRiskData();
  }, []);

  // Popover handlers
  const handleMouseEnter = (event) => {
    if (popoverTimeout.current) clearTimeout(popoverTimeout.current);
    setAnchorEl(event.currentTarget);
  };

  const handleMouseLeave = () => {
    popoverTimeout.current = setTimeout(() => {
      setAnchorEl(null);
    }, 200);
  };

  const open = Boolean(anchorEl);
  const id = open ? "bar-chart-popover" : undefined;

  return (
    <Paper sx={{ p: 3, height: 500, width: "100%" }}>
      {/* Title and Info Icon */}
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <Typography variant="h6" sx={{ fontWeight: "bold" }}>
          Risk Level Distribution
        </Typography>
        <IconButton
          aria-describedby={id}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          <InfoIcon sx={{ color: "#000000" }} />
        </IconButton>
      </Box>

      {/* Hover Popover */}
      <Popover
        id={id}
        open={open}
        anchorEl={anchorEl}
        onClose={() => setAnchorEl(null)}
        anchorOrigin={{
          vertical: "bottom",
          horizontal: "left",
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left",
        }}
        disableRestoreFocus
        sx={{
          pointerEvents: "none", // Ensures smooth disappearance on hover out
        }}
      >
        <Box sx={{ p: 2, maxWidth: 300 }}>
          <Typography variant="subtitle1" fontWeight="bold">
            About this Chart
          </Typography>
          <Typography variant="body2" color="textSecondary">
            This bar chart shows the distribution of files across different risk
            levels. High-risk files are represented in red, medium-risk in
            orange, and low-risk in green.
          </Typography>
        </Box>
      </Popover>

      {/* Bar Chart */}
      <ResponsiveContainer width="100%" height="90%">
        <BarChart data={data} barSize={80}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="riskLevel" />
          <YAxis />
          <Tooltip cursor={{ fill: "rgba(0, 0, 0, 0.1)" }} />
          <Legend />
          <Bar dataKey="files" radius={[10, 10, 0, 0]}>
            {data.map((entry, index) => (
              <Cell
                key={`cell-${index}`}
                fill={COLORS[entry.riskLevel]}
                style={{
                  transition: "transform 0.3s ease-in-out",
                }}
                onMouseEnter={(e) => (e.target.style.transform = "scale(1.05)")}
                onMouseLeave={(e) => (e.target.style.transform = "scale(1)")}
              />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </Paper>
  );
};

export default BarChartComp;
